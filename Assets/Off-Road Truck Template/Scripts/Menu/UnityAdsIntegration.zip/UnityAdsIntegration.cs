﻿using UnityEngine;
using System.Collections;
using UnityEngine.Advertisements;
using UnityEngine.UI;

public class UnityAdsIntegration : MonoBehaviour
{

	[SerializeField] private string androidGameId = "18658"; //ID for testing
	[SerializeField] private string iOSGameId = "18658"; //ID for testing
	public string zoneId = "rewardedVideo";

	[Space(3)]
	[SerializeField] bool enableTestMode;


	[Header("Status Text")]
	public Text StatusText;

	[Header("Coins Text")]
	public Text AwardText;

	[Header("Awarded Coins")]
	public int AwardedCoins = 1000;

	void Start ()
	{
		AwardText.text = PlayerPrefs.GetInt ("Coins").ToString ();

		string gameId = null;

		#if UNITY_ANDROID
		gameId = androidGameId;
		#else
		gameId = iOSGameId;
		#endif

		if(Advertisement.isInitialized) {
			StatusText.text = "Unity Ads is already initialized";
		} 
		else {
			StatusText.text = "Failed to initialize Unity Ads";

			Advertisement.Initialize(gameId, enableTestMode);
		}
	}




	public void Show()
	{
		ShowOptions options = new ShowOptions();
		options.resultCallback = HandleShowResult;


			Advertisement.Show (zoneId, options);

	}



	private void HandleShowResult (ShowResult result)
	{
		switch (result)
		{
		case ShowResult.Finished:
			PlayerPrefs.SetInt ("Coins", PlayerPrefs.GetInt ("Coins") + AwardedCoins);
			AwardText.text = PlayerPrefs.GetInt ("Coins").ToString ();
			break;
		case ShowResult.Skipped:
			StatusText.text =  "Video was skipped";
			break;
		case ShowResult.Failed:
			StatusText.text =  "Video failed to show";
			break;
		}
	}


	public void LoadLevelName(string name)
	{

		UnityEngine.SceneManagement.SceneManager.LoadScene (name);
	}
}